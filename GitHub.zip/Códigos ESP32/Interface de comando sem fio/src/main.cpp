//==================================================================================================
/*
Código utilizado para o envio de um sinal de referência de forma sem fio para o controlador de 
velocidadede um motor CC.

Desenvolvido em abril de 2023.

Baseado em: https://randomnerdtutorials.com/esp-now-esp32-arduino-ide/
*/
//================================================================================================== 

// Bibliotecas necessárias
#include <esp_now.h>
#include <WiFi.h>

// Definição dos parâmetros do potenciômetro
const int pino_pot = 36;  // Pino de conexão no ESP32
float calibracao_pot = 0; // Variável utilizada para calibrar o ESP32 dentro da caixa 
int leitura_pot = 0;      // Variável que armazena a leitura do potenciômetro

// Definição do endereço MAC para onde será enviado o valor da leitura do potenciômetro
uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; // Envia para todos dispositivos

// Estrutura para o envio de dados via Wi-Fi
typedef struct struct_message {
  int referencia;
} struct_message;

// Criação da mensagem a ser enviada via Wi-Fi
struct_message mensagem;
esp_now_peer_info_t peerInfo;

// Função chamada quando a mensagem é enviada
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
}

//================================================================================================== 

void setup() { 
  // Configuração do microcontrolador como uma estação Wi-Fi
  WiFi.mode(WIFI_STA);

  // Inicialização da biblioteca ESP-NOW
  if (esp_now_init() != ESP_OK) {
    return;
  }

  // Registro para obtenção do status da transmissão
  esp_now_register_send_cb(OnDataSent);
  
  // Registro do par de comunicação
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  // Adição de um par na comunicação       
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    return;
  }

  // Configuração do LED de exibição da magnitude do sinal de referência
  pinMode(2, OUTPUT);    // Pino de conexão do LED
  ledcAttachPin(2, 0);   // Atribuição do canal de geração de PWM
  ledcSetup(0, 100, 12); // Definição de uma frequência de 100Hz com resolucao de 12bits.
}

//================================================================================================== 

void loop() {
  // Leitura e calibração do potênciometro 
  leitura_pot = analogRead(pino_pot); 
  calibracao_pot = leitura_pot-790;

  if (calibracao_pot < 0) calibracao_pot = 0;
  calibracao_pot = calibracao_pot / 2000;
  if (calibracao_pot > 1) calibracao_pot = 1;
  leitura_pot = calibracao_pot * 4095;

  // Acionamento do LED de acordo com a leitura do potenciômetro
  ledcWrite(0, leitura_pot);

  // Envio da leitura do potenciômetro via Wi-Fi
  mensagem.referencia = leitura_pot;
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &mensagem, sizeof(mensagem));
  
  delay(10);
}

//================================================================================================== 
