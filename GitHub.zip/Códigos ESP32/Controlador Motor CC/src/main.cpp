//==================================================================================================
/*
Código utilizado para o recebimento de um sinal de referência de forma sem fio, envio e recebimento 
de dados entre o ambiente Simulink e o microcontrolador, leitura de um sensor de velocidade e 
acionamento de um motor CC.  

Desenvolvido em abril de 2023.

Baseado em: https://randomnerdtutorials.com/esp-now-esp32-arduino-ide/  
            https://www.youtube.com/watch?v=wj-EGwmY6Fo                 
*/
//==================================================================================================

// Bibliotecas necessárias
#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>

// Variáveis
unsigned long tempo_envio = 0;              // Definição do tempo de envio de dados para o Simulink
const int pino_sensor_velocidade = 36;       // Pino de conexão do sensor de velocidade  
float leitura_velocidade = 0;                // Valor da velocidade medida

// Variáveis usadas na comunicação com o ambiente Simulink
union BtoF
{
 byte b[16];
 float fval; 
} u;

const int buffer_size = 16;
byte buf[buffer_size];

float data;

// Função para recebimento de dados do ambiente Simulink
float recebe_simulink()
{
 int reln = Serial.readBytesUntil('\n', buf, buffer_size);
 for (int i=0; i<buffer_size; i++)
 {
  u.b[i] = buf[i];
 }
 float output = u.fval;
 return output;
}

// Função para envio de dados para o ambiente Simulink
void envia_simulink (float number)
{
 byte *b = (byte *) &number;
 Serial.write(b,4);
}

// Estrutura para o recebimento de dados via Wi-Fi
typedef struct struct_message {
    int referencia;
} struct_message;

// Criação da mensagem a ser recebida via Wi-Fi
struct_message mensagem;

// Função chamada quando a mensagem é recebida
void OnDataRecv(const uint8_t * mac, const uint8_t *incomingData, int len) {
  memcpy(&mensagem, incomingData, sizeof(mensagem));
}

//==================================================================================================
 
void setup() {
  // Configuração da porta serial 
  Serial.begin(115200);
  
  // Configuração do microcontrolador como uma estação Wi-Fi
  WiFi.mode(WIFI_STA);

  // Inicialização da biblioteca ESP-NOW
  if (esp_now_init() != ESP_OK) {
    return;
  }
  
  // Registro para obtenção do status da transmissão
  esp_now_register_recv_cb(OnDataRecv);

  // Configurações do acionamento do Motor CC
  pinMode(2, OUTPUT);    // Pino de conexão do buffer
  ledcAttachPin(2, 0);   // Atribuição do canal de geração de PWM
  ledcSetup(0, 100, 12); // Definição de uma frequência de 100Hz com resolucao de 12bits.
  ledcWrite(0,0);        //Inicialização com motor desligado
}

//==================================================================================================
 
void loop() {
  // Medição do tempo
  unsigned long tempo_atual = millis();

  if (tempo_atual - tempo_envio >= 10){
    // Leitura da velocidade
    leitura_velocidade = analogRead(pino_sensor_velocidade);
    // Envio do sinal de referência para o Simulink    
    envia_simulink((float)(mensagem.referencia));     
    // Envio do sinal de velocidade para o Simulink
    envia_simulink(leitura_velocidade); 
    Serial.write(10); // "\n" LF    
    delay(2); 

    // Recebimento do sinal de controle do Simulink
    float sinal_motor = recebe_simulink();
    delay(2); 
    // Geração do sinal de PWM
    ledcWrite(0, (int)sinal_motor);

    tempo_envio = tempo_atual;
  } 
       
}

//==================================================================================================
